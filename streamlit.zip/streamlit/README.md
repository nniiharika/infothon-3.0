# Streamlit Demo App

For video tutorial: [Streamlit: The Fastest Way To Build Python Apps?](https://www.youtube.com/watch?v=D0D4Pa22iG0&lc=Ugz_mHQgRHlnn1BJqlx4AaABAg)
